library(testthat)
library(rvcstats)

test_check("rvcstats")
