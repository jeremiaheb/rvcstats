## Returns: a STRAT object with weights (wh) for each stratum and year
## Given selected years (defualt = "all") and strata (default = "all").
## If includes.protected then substrata with protected status will be 
## searched for in data with the variable name PROT
stratData = function(data, years = "all", strata = "all", includes.protected = FALSE){
  ## Check to make sure required variables are present 
  names(data) = toupper(names(data))
  reqd = c("YEAR", "STRAT", "NTOT")
  .inList("Required Variable", reqd, names(data))
  
  ## If strata set to all, select all strata
  if (all(strata != "all")){
    data = subset(data, STRAT %in% strata)
  }
  
  ## If years set to all select all years
  if (all(years != "all")){
  data = subset(data, YEAR %in% years)
  }
  
  ## Select variables to aggregate by
  agg.by = c("YEAR", "STRAT")
  
  ## If includes.protected is TRUE add includes protected to agg.by
  if (includes.protected){
    .inList("protection status variable", "PROT", names(data))
    agg.by = c(agg.by, "PROT")
  }
  
  ## Subset and aggregate (if neccessary) by agg.by variables
  agg.by = as.list(data[agg.by])
  newData = aggregate(data$NTOT, by = agg.by, FUN = sum)
  names(newData)[length(names(newData))] = "NTOT"
  
  ## Change class to STRAT
  class(newData) = "STRAT"
  
  return(newData)
}